<?php

require_once("config.php");

function get_param($param_name)
{
  global $HTTP_POST_VARS;
  global $HTTP_GET_VARS;
  $param_value = "";
  if(isset($HTTP_POST_VARS[$param_name]))
    $param_value = $HTTP_POST_VARS[$param_name];
  else if(isset($HTTP_GET_VARS[$param_name]))
    $param_value = $HTTP_GET_VARS[$param_name];
  return $param_value;
}

function filegetcontents($fn)
{
  $ret = "";

  $fp = fopen($fn, "r");
  if($fp)
  {
    $ret = fread($fp, filesize($fn));
    fclose($fp);
  }

  return($ret);
}


function clean_user_input($str) {
  global $comments_sep;
  $str = strip_tags($str);
  $str = htmlspecialchars($str);

  do
  {
    $lstr=$str;
    $str=ereg_replace($comments_sep,"",$lstr);
  } while ($lstr != $str);

  return $str;
}

function comments_addcomment($articleid, $username, $userip, $comment, $time) {
  global $comments_dir, $comments_sep;

  if (($username == $comment && !strstr($username," ")) ||
      strstr($username,"\n") ||
      stristr($username,"MIME-Version") || // ignore some weird spam stuff
      stristr($comment,"MIME-Version")) return 0;

  // verify user input
  $articleid |= 0;
  $username = clean_user_input($username);
  $comment = clean_user_input($comment);

  $oldcomments = "";

  $towrite = $username.$comments_sep.$userip.$comments_sep.$comment.$comments_sep.$time."\n";

  $fp = fopen("$comments_dir/$articleid", "a+");
  if($fp) {

    if (flock($fp,2))
    {
      fseek($fp,0,SEEK_END);
      $pos=ftell($fp);
      if ($pos > 0) fwrite($fp,$comments_sep);
      fwrite($fp, $towrite);
    }

    fclose($fp);
    return 1;
  }

  return 0;
}

function comments_getcomments($articleid)
{
  global $comments_dir, $comments_sep;

  if(file_exists("$comments_dir/$articleid"))
    return(filegetcontents("$comments_dir/$articleid"));
  else
    return("");
}

function auto_link($str)
{
  $res="";
  while (($x = stristr($str,"http://")))
  { 
    $res .= substr($str,0,strlen($str)-strlen($x));

    $list = array('<','>','"',' ',"\t","\r","\n",0);
    $ny=0;
    for ($y = 0; $list[$y]; $y ++)
    {
      if (($tmp=strstr($x,$list[$y])) && strlen($tmp) > 0)
        if (strlen($tmp) > $ny) $ny=strlen($tmp);
    }
    $ny = strlen($x)-$ny;
    
    if ($ny > 7)
    {
      $su=substr($x,0,$ny);
      $ml=64;
      $sub=substr($su,7,$ml) . ($ny > $ml-7 ? "..." : "");
      $res .= "<a href=\"$su\" rel=\"nofollow\">$sub</a>";
    }

    $str=substr($x,$ny);
  }
  $res .= $str;
  return $res;
}

function comments_formatoutput($str)
{
  $str = trim($str);
  if ($str == "") return "-";
  $ret = "";

  $ret = str_replace("  ", "&nbsp;&nbsp;", str_replace("\n", "<br />", stripslashes(htmlentities(auto_link(strip_tags($str))))));
  $ret = html_entity_decode($ret); //str_replace("&amp;quot;","&quot;",$ret);

  return($ret);
}

function comments_getdispcomments($article)
{
  global $comments_enabled, $comments_sep, $comments_dispsep, $comments_datestr, $article_comments, $blogurl;
  $article_comments = "";

  if($comments_enabled)
  {
    // process new comment 
    if(get_param("addcomment") != "")
    {
      $user_info = $_SERVER['REMOTE_ADDR'];
      $entry_id = get_param("nid");	// untrusted!
      $text = get_param("addcomment");	// untrusted!
      $name = get_param("name");	// untrusted!
      $time = date($comments_datestr);

      $res = comments_addcomment($article, $name, $user_info, $text, $time);

      echo("<script>document.location='$blogurl?article={$article}';</script>");
    }

    $comments = comments_getcomments($article);  

    
    {
      $comments = explode($comments_sep, $comments);
      $commentcount = (sizeof($comments) / 4)|0;

      $article_comments = "<table width=100% border=0><tr><td colspan=3><a name=\"c".$article."\"></a><b><u>Comments($commentcount)</u></b><br />";
      
      if($commentcount >= 1)
      {
        for($i = 0; $i < $commentcount * 4; $i += 4)
        {
          $name = $comments[$i];
          $ip = $comments[$i+1];
          $text = $comments[$i+2];
          $datestr = $comments[$i+3];

 	  $tmp=strrchr($ip,".");
          $ip=substr($ip,0,-strlen($tmp)) . ".x";

          $ii=(int) ($i/4);
          $article_comments .= "<a name=\"cl$ii\"><font class=\"comments\">Posted by <b>" . comments_formatoutput($name) . "</b> on $datestr from $ip<ul>" . comments_formatoutput($text) . "</ul></font>$comments_dispsep";
        }
      }

      $article_comments .= "<form action=\"$blogurl?article=$article\" method=\"POST\" style=\"display: inline;\">
            <input type=\"hidden\" name=\"nid\" value=\"$article\">
            <table width=\"50%\" cellpadding=0 cellspacing=0 border=0>
              <tr>
              <td><b>Name:</b></td>
              <td align=\"left\"><input class=myform type=\"text\" size=\"75\" maxlength=\"100\" name=\"name\"></td>
              </tr>
              <tr>
              <td><b>Comment:</b></td>
              <td align=\"left\"><textarea class=myform cols=75 rows=5 name=\"addcomment\"></textarea></td>
              </tr>
              <tr><td></td>
              <td colspan=><input class=myform type=\"submit\" value=\"Add Comment\" style=\"display: inline;\"></td>
              </tr>
              </table>
              </form></td></tr></table>";
    }
  return($article_comments);
  }
  return("");
}

function comments_getcommentlink($article)
{
  global $comments_dir, $comments_sep;

  $article |= 0;

  if (file_exists("$comments_dir/$article") && ($comments = filegetcontents("$comments_dir/$article")))
  {
    $arr = explode($comments_sep, $comments);
    $count = ((sizeof($arr) / 4))|0;
  }
  else $count=0;

  return("<a href=\"?article=$article\">Comments ($count)</a>");
}


  function display_article($article_parm, $adone)
  {
    global $article_dir, $viewstart;
    global $hls_article_date_column_width, $center_article, $comments_enabled, $is_palm;

    global $refer_maxitems, $refer_maxdispsize,$refer_dir, $refer_label;

    $show_full = substr($article_parm,-1) == "F";
    $article_parm |= 0;

    $fn = "$article_dir/$article_parm";
    $fp = @fopen($fn, "rt");
    if (!$fp) return $adone;

    $firstline = trim(fgets($fp, 1024));
    if ($viewstart != "" ||
        (($r = strtotime($firstline))==-1) || 
          $r <= strtotime("now") ) 
    {
      if ($adone>0)
      {
        echo "<tr><td colspan=3>";
        echo "<hr width=\"85%\">\n";
        echo "</td></tr>\n";
      }

      echo "<tr><td width=\"$hls_article_date_column_width\" valign=top><b>";

      if (substr($firstline, 0, 1) != "\\") 
      {
        echo $firstline;
        $r = strtotime($firstline);
        if ($r !== -1 && $r !== 0) {
          echo "<br><center><font face=\"courier\" size=\"-1\">". strtolower(strftime("%A", $r)) . "</font></center>\n";
        }
        $firstline = "";
      }
      echo "&nbsp;</td><td>";
      if ($center_article) echo "<center>";
    }

    // process article
    $last_empty=1;
    while ($firstline != "" || ($str = fgets($fp, 4096)) !== false) 
    {
      // recycle first line if they put a topic there
      if ($firstline != "") $str = $firstline;
      $firstline = "";
// new topic
      if (substr($str, 0, 1) == "\\") 
      {
       if (substr($str, 0, 2) == "\\\\") 
       {
         echo substr($str, 1);
       } 
       else 
       {
         $str = trim(substr($str, 1));	// trim off \ and \n
         echo "<a name=\"art$article_parm\">";
         $link1="";
         $link2="";
         if (!$show_full) { $link2="</a>"; $link1="<a href=\"?article=$article_parm\">"; }
         echo "<font size=+2><b>$link1" . $str . "$link2</b></font><p>\n";
       }
     } 
     else 
     {
       if (rtrim($str) == "")
       {
         if (!$last_empty) $str="<p>";
         else $last_empty=1;
       }
       else $last_empty=0;

       $str=eregi_replace("<pre>","",$str);
       $str=eregi_replace("</pre>","",$str);

       if (substr(ltrim($str),0,1) == "*" || substr(ltrim($str),0,1) == '+') $str = "<p>$str" ;

       $str=eregi_replace("<img src.*>",'\\0<p>',$str);

       echo $str;
     }
   }
   fclose($fp);

   if ($center_article) echo "</center>";
   echo "</td></tr>\n";
   if ($comments_enabled) 
   {
     echo("<tr><td>&nbsp;</td><td colspan=2>");
     if(!$show_full) echo(comments_getcommentlink($article_parm));
     else echo(comments_getdispcomments($article_parm));
     echo("</td></tr>");
   }
   if ($show_full && !$is_palm)
   {
     $rfp = @fopen("$refer_dir/$article_parm",$refer == "" ? "r" : "a+");
     $rcnt=0;
     if ($rfp)
     {
       fseek($rfp,0,SEEK_SET);
       while (($x = fgets($rfp,1024)))
       {
         $x=rtrim($x);
         if ($x != "") 
         {
           if (!$rarr[$x])
           {
             if (!$rcnt)
             {
               echo "<tr><td></td><td><hr>$refer_label<BR>";
             }
             $rcnt++;
           }
           $rarr[$x]=1;
           $sx=$x;
           if (strlen($sx) > $refer_maxdispsize) $sx = substr($sx,0,$refer_maxdispsize) . "...";
           if ($rcnt < $refer_maxitems) echo "<a href=\"$x\" rel=\"nofollow\">$sx</a><BR>";
         }
       }
       if ($refer != "" && !$rarr[$refer])
       {
         if (@flock($rfp,LOCK_EX)) fwrite($rfp,$refer . "\n");
       }
       fclose($rfp);
       if ($rcnt)
       {
         echo "</td></tr>";
       }
     }
    }
    return $adone+1;
  }

  function make_desc($fp) {
    global $rss_num_desc_words;
    $prevpos = ftell($fp);
    $wc = 0;
    $ret = "";
    while ($wc < $rss_num_desc_words) {
      $str = fgets($fp, 1024);
      if ($str === false) break;
      if (substr($str, 0, 1) == "|") {
        continue;
      }
      $str = str_replace("\r", "", $str);	// lame, should be trim
      $str = str_replace("\n", " ", $str);
      if (substr($str, 0, 1) == "\\") break;
      $wc += str_word_count(strip_tags($str));
      $ret .= $str;
      $prevpos = ftell($fp);
    }
    fseek($fp, $prevpos);
    $ret = strip_tags($ret);
    if ($wc >= $rss_num_desc_words) {
      $ret = rtrim($ret, " .,?!");
      if (substr($ret, -1) != "\"") $ret .= "..."; // "bla endquote"... looks bad
    }
    return $ret;
  }

  function make_full($fp) {
    $ret = "";
    $prevpos = ftell($fp);

    global $center_article;
    if ($center_article) $ret .= "<center>";

    $last_empty=1;
    while (($str = fgets($fp, 1024)) !== false) {
      $str = str_replace("\r", "", $str);	// lame, should be trim

      $str=config_rss_fixstr($str);

      if (rtrim($str) == "")
      {
        if (!$last_empty) $str="<p>";
        else $last_empty=1;
      }
      else $last_empty=0;

      $str=eregi_replace("<pre>","",$str);
      $str=eregi_replace("</pre>","",$str);

      if (substr(ltrim($str),0,1) == "*" || substr(ltrim($str),0,1) == '+')
      {
          $str = "<p>$str" ;
      }

      $str=eregi_replace("<img src.*>",'\\0<p>',$str);


      if (substr($str, 0, 1) == "\\") break;
      $ret .= $str;
    }
    fseek($fp, $prevpos);
    if ($center_article) $ret .= "</center>";
    return $ret;
  }


?>
